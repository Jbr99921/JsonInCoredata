
//

import Foundation
import CoreData


public class Photo: NSManagedObject {

}
